module.exports = {
    run: async (message, args) => {
        if (!message.member.hasPermission('BAN_MEMBERS')) return message.channel.send('Vous n\'avez pas la permission d\'utiliser cette commande. :DENIED: ')
        const member = message.mentions.members.first()
        if (!member) return message.channel.send('Veuillez mentionner le membre à bannir. :DENIED: ')
        if (member.id === message.guild.ownerID) return message.channel.send('Vous ne pouvez pas bannir le propriétaire du serveur. :DENIED: ')
        if (message.member.roles.highest.comparePositionTo(member.roles.highest) < 1 && message.author.id !== message.guild.ownerID) return message.channel.send('Vous ne pouvez pas Bannir ce membre. :DENIED: ')
        if (!member.bannable) return message.channel.send('Le bot ne peut pas bannir ce membre. :DENIED: ')
        const reason = args.slice(1).join(' ') || 'Aucune raison fournie. Powerred by : CANISTOR_CORP'
        await member.ban({reason})
        message.channel.send(`${member.user.tag} a été banni avec succès! Powered by : CANISTERS_CORP :SUCCESS: `)
    },
    name: 'ban',
    guildOnly: true}
module.exports = {
    run: message => message.channel.send('Le bot es ok!!! :SUCCESS: '),
    name: 'status'
}